# https://www.instagram.com/keval_king_212/"

import speech_recognition as sr
import google.generativeai as genai
import os
import webbrowser 
import pyttsx3
import musicLibrery 
import requests

recognizer = sr.Recognizer()

engine = pyttsx3.init()

newsapi ="Your news api"
api_key = "Your gemini api"

genai.configure(api_key=api_key)

def aiProcess(command):
    """Process command using Gemini AI (GPT-like model)."""

    try:
        model = genai.GenerativeModel('gemini-1.5-flash')
        chat = model.start_chat(history=[])
        response = chat.send_message(command)
        return response.text

    except Exception as e:
        print(f"Error with Gemini API: {e}")
        return "Sorry, I couldn't process that."

def proccessCommand(c):

    if "open google"in c.lower():
        webbrowser.open("https://www.google.com/")
        speak("Opening Google...")

    elif "open facebook"in c.lower():
        webbrowser.open("https://www.facebook.com/")
        speak("Opening facebook...")

    elif "open instagram " in c.lower():
        webbrowser.open("https://www.instagram.com/keval_king_212/")
        speak("Opening instagram  ...")

    elif "open youtube"in c.lower():
        webbrowser.open("https://www.youtube.com/")
        speak("Opening youtube...")

    elif "open ai"in c.lower():
        webbrowser.open("https://www.chatgpt.com/")
        speak("Opening chatGPT...")

    elif "open telegram "in c.lower():
        webbrowser.open("https://telegram.org/")
        speak("Opening Telegram...")

    elif "open github" in c.lower():
        print("Command recognized: Open GitHub")
        webbrowser.open("https://github.com/")
        speak("Opening GitHub...")


    elif "open whatsapp"in c.lower():
        webbrowser.open("https://web.whatsapp.com/")
        speak("Opening whatsapp...")

    elif c.lower().startswith("play"):
        song = c.lower().split(" ")[1]
        if song in musicLibrery.music:
            link = musicLibrery.music[song]
            webbrowser.open(link)
            speak(f"Playing {song}...")
        else:
            speak(f"Sorry, I couldn't find the song {song}.")

    else:
        #Let Gemini AI Handel the request 
        # Let Gemini AI handle the request

        ai_response = aiProcess(c)

        # Print the response and speak it aloud
        print(f"Best Friend Response : {ai_response}")
        speak(ai_response)

def speak(text):

    engine.say(text)
    engine.runAndWait()

if __name__=="__main__":

    speak("Initializing Jarvis....")

    while True:
        #listen for the wake word "Best friend"
        # obtain audio from the microphone
        r = sr.Recognizer()

        print("Recognizig...")
        # recognize speech using Sphinx
        try:
            with sr.Microphone() as source:
                print("Listening...")
                audio=r.listen(source,timeout=2,phrase_time_limit=2)

            word = r.recognize_google(audio)
    
            if(word.lower()=="jarvis"):
                speak("Yes, how can I help you?")      

                #Listing Foe =r Command
                with sr.Microphone() as source:
                    print("Jarvis Active...")
                    audio=r.listen(source)
                    command = r.recognize_google(audio)
                    print(f"You said: {command}")
                    proccessCommand(command)

        except sr.UnknownValueError:
            print( "Sorry, I didn't catch that.")
            speak("Sorry, I didn't catch that.")

        except sr.RequestError:
            print( "Sorry, there was an issue with the request.")
            speak("Sorry, there was an issue with the request.")

# ✅ How It Works (Step-by-Step)
# Program Starts
# → It says: "Initializing Jarvis..."

# Listening for Wake Word
# → You say: "Jarvis"

# Jarvis Responds
# → It replies: "Yes, how can I help you?"

# Say a Command
# → Example: "Open YouTube"

# Jarvis Opens Website

# → Browser opens YouTube
# → Says: "Opening YouTube..."

# Other Supported Commands:

# "Open Google"

# "Open Instagram"

# "Open Facebook"

# "Open GitHub"

# "Open WhatsApp"

# "Play [song name]" (from your musicLibrary dictionary)

# General Questions → handled by Gemini AI

# Can't Understand?
# → If voice is unclear, it says: "Sorry, I didn't catch that."