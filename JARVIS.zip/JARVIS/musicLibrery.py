music = {
    "kabira": "https://www.youtube.com/watch?v=jHNNMj5bNQw&list=RDjHNNMj5bNQw&index=1&pp=8AUB",
    "perfect": "https://www.youtube.com/watch?v=kPhpHvnnn0Q&pp=ygUDcGVy",
    "ae dil hai mushkil": "https://www.youtube.com/watch?v=6FURuLYrR_Q&list=RDjHNNMj5bNQw&index=5&pp=8AUB",
    "baarish": "https://www.youtube.com/watch?v=PJWemSzExXs&pp=ygUKYmFycmlzaGVpbg%3D%3D",
    "thousand" : "https://www.youtube.com/watch?v=-X-Ls1APDjQ&list=RD-X-Ls1APDjQ&index=1&pp=8AUB",
    "nadan" : "https://www.youtube.com/watch?v=gPpQNzQP6gE&pp=ygUIbmFkYW5peWE%3D",
    "love" : "https://www.youtube.com/watch?v=XTHdMtxrj-w&pp=ygUEaXNocQ%3D%3D"
    }